<div class="clear"></div>
<div id="footer">
    <ul class="right">
    	<li>© Hotel Booking System</li>
    </ul>
    <div class="clear"></div>
</div>
</body>
</html>
